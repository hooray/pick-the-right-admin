import{_ as o}from"./sub.vue_vue_type_script_setup_true_lang-DkFuZ_hh.js";import"./index-D8kZ2dnq.js";import"./item.vue_vue_type_script_setup_true_lang-DveDsvPI.js";export{o as default};
